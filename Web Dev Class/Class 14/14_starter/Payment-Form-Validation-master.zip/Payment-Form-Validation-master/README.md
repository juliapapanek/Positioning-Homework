# Payment Form Validation

- In this lab we will be creating validation on a payment form using either conditional statements.
- Here is the specification for the form:
	- FIRST NAME: Must not be blank
	- LAST NAME: Must not be blank
	- CREDIT CARD NUMBER: 16 Digits only numbers
	- (bonus) EXPIRATION DATE: Format MM/DD numbers only 
	- CVC: 3 Digits only numbers
